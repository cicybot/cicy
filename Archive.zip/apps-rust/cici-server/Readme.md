
brew install sqlcipher
cargo build --release
