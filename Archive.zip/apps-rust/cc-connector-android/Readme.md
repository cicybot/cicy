# 初始化 Rust

    cd apps
    cargo new rust_hello

# Rust run

    cargo run
    cargo run -- -h

    cargo build --release

